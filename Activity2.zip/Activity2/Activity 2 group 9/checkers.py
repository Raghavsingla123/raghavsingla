#This code was created by Raghav Singla, Abdulla, Dhanraaj Satwani
import turtle as t

def initialize_screen():

    t.speed(0)  
    t.hideturtle()
    t.bgcolor("white")
    t.tracer(0)  

def draw_pixel(col, x_pos, y_pos, pixel_sz=20):
    """
    Draw a colored pixel at the specified (x, y) position.
    
    Args:
    - col (str): Color of the pixel to be drawn.
    - x_pos (int): X-coordinate for the pixel.
    - y_pos (int): Y-coordinate for the pixel.
    - pixel_sz (int, optional): Size of the pixel. Defaults to 20.
    """
    t.up()
    t.goto(x_pos, y_pos)
    t.down()
    t.color(col)
    t.begin_fill()
    for _ in range(4):
        t.forward(pixel_sz)
        t.left(90)
    t.end_fill()

def draw_checkerboard(sz, pixel_sz=20):
    # Draw a checkerboard pattern using turtle graphics centered on the screen.
    
    start_x = -(sz * pixel_sz) / 2
    start_y = (sz * pixel_sz) / 2

    for r in range(sz):
        for c in range(sz):
            x = start_x + c * pixel_sz
            y = start_y - r * pixel_sz
            
            # Alternate colors between red and black
            if (r + c) % 2 == 0:
                col = "red"
            else:
                col = "black"
            
            draw_pixel(col, x, y, pixel_sz)

def main():
    initialize_screen()
    draw_checkerboard(20)
    t.done()

if __name__ == "__main__":
    main()
