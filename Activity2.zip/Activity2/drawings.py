#This code was created by Raghav Singla, Abdulla, Dhanraaj Satwani
import turtle as t

def color_blk():
    """Returns the color corresponding to the '0' character."""
    return "black"

def color_wht():
    """Returns the color corresponding to the '1' character."""
    return "white"

def color_r():
    """Returns the color corresponding to the '2' character."""
    return "red"

def color_y():
    """Returns the color corresponding to the '3' character."""
    return "yellow"

def color_o():
    """Returns the color corresponding to the '4' character."""
    return "orange"

def color_g():
    """Returns the color corresponding to the '5' character."""
    return "green"

def color_yg():
    """Returns the color corresponding to the '6' character."""
    return "yellowgreen"

def color_s():
    """Returns the color corresponding to the '7' character."""
    return "sienna"

def color_t():
    """Returns the color corresponding to the '8' character."""
    return "tan"

def color_gy():
    """Returns the color corresponding to the '9' character."""
    return "gray"

def color_dgy():
    """Returns the color corresponding to the 'A' character."""
    return "darkgray"

def get_color(ch):
    """Returns the color corresponding to the given character."""
    return {
        '0': color_blk(),
        '1': color_wht(),
        '2': color_r(),
        '3': color_y(),
        '4': color_o(),
        '5': color_g(),
        '6': color_yg(),
        '7': color_s(),
        '8': color_t(),
        '9': color_gy(),
        'A': color_dgy(),
    }.get(ch, None)

def draw_px(clr):
    """Draws a single pixel using turtle of the given color."""
    t.pendown()
    t.begin_fill()
    t.fillcolor(clr)
    for _ in range(4):
        t.forward(20)
        t.left(90)
    t.end_fill()
    t.penup()
    t.forward(20)

def draw_px_str(s, st_y):
    """Draws a row of pixels using turtle based on a string of color characters."""
    t.speed(0)
    t.width(1)
    t.penup()
    t.goto(-len(s) * 20 / 2, st_y)
    
    for ch in s:
        clr = get_color(ch)
        if clr is None:
            return False
        draw_px(clr)
    
    return True

if __name__ == "__main__":
    str_in = input("enter the string of colors: ")

    str_arr = str_in.splitlines()
    st_y = len(str_arr) * 20 / 2  

    for i in str_arr:
        res = draw_px_str(i, st_y)
        st_y -= 20  
    if res:
        print("All pixels drawn successfully!")
    else:
        print("Encountered an invalid color character.")
t.done()
